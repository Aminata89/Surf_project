from surf_scrap import scrape_surf

if __name__ == "__main__":
    url = "https://www.surf-report.com/meteo-surf/lacanau-s1043.html"
    save_path = "data/surf_data.csv"

    df = scrape_surf(url, save_path, year=2026)
    print("✅ CSV créé :", save_path)
    print("✅ Lignes :", len(df))
    print(df.head(5))
