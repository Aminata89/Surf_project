import re
import requests
import pandas as pd
from bs4 import BeautifulSoup


def scrape_surf(url: str, save_path: str, year: int = 2026) -> pd.DataFrame:
    """
    Scrape surf-report forecast and save CSV to the desired location.

    Parameters
    ----------
    url : str
        Example:
        https://www.surf-report.com/meteo-surf/lacanau-s1043.html
    save_path : str
        Example:
        data/surf_data.csv
    year : int
        Year to build the datetime column (default 2026)

    Returns
    -------
    pd.DataFrame
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/537.36 Chrome Safari"
    }
    html = requests.get(url, headers=headers, timeout=25).text
    soup = BeautifulSoup(html, "html.parser")

    data = []

    for day in soup.select("div.forecast-tab"):
        date_tag = day.select_one("div.title b")
        if not date_tag:
            continue
        date = date_tag.get_text(strip=True)

        lines = day.select("div.line")
        for line in lines[1:]:
            heure_tag = line.select_one("div.cell.date")
            vagues_tag = line.select_one("div.cell.large.waves")
            vent_speed_tag = line.select_one("div.wind span") or line.select_one("div.wind")

            # direction : parfois img alt/title
            wind_img = line.select_one("div.wind img")
            vent_dir = None
            if wind_img:
                vent_dir = wind_img.get("alt") or wind_img.get("title")

            if not (heure_tag and vagues_tag and vent_speed_tag):
                continue

            heure = heure_tag.get_text(strip=True)
            vagues = vagues_tag.get_text(strip=True)

            vent_speed_txt = vent_speed_tag.get_text(" ", strip=True)
            m = re.search(r"(\d+)", vent_speed_txt)
            vent_speed = int(m.group(1)) if m else None

            data.append(
                {
                    "date": date,
                    "heure": heure,
                    "vagues": vagues,
                    "vent_vitesse_kmh": vent_speed,
                    "vent_direction": vent_dir,
                }
            )

    df = pd.DataFrame(data)

    # --- Nettoyages / transformations (ta logique) ---
    # Séparer vagues min/max
    df[["vague_min", "vague_max"]] = (
        df["vagues"]
        .str.replace("m", "", regex=False)
        .str.replace(",", ".", regex=False)
        .str.split("-", expand=True)
    )
    df["vague_min"] = pd.to_numeric(df["vague_min"].str.strip(), errors="coerce")
    df["vague_max"] = pd.to_numeric(df["vague_max"].str.strip(), errors="coerce")

    # Nettoyer direction
    df["vent_direction"] = (
        df["vent_direction"]
        .fillna("")
        .str.replace("Orientation vent ", "", regex=False)
        .str.strip()
    )

    # Convertir date FR -> EN pour datetime
    mois_fr_en = {
        "Janvier": "January", "Février": "February", "Mars": "March", "Avril": "April",
        "Mai": "May", "Juin": "June", "Juillet": "July", "Août": "August",
        "Septembre": "September", "Octobre": "October", "Novembre": "November", "Décembre": "December"
    }
    jours_fr_en = {
        "Lundi": "Monday", "Mardi": "Tuesday", "Mercredi": "Wednesday", "Jeudi": "Thursday",
        "Vendredi": "Friday", "Samedi": "Saturday", "Dimanche": "Sunday"
    }

    df["date_en"] = df["date"]
    for fr, en in mois_fr_en.items():
        df["date_en"] = df["date_en"].str.replace(fr, en, regex=False)
    for fr, en in jours_fr_en.items():
        df["date_en"] = df["date_en"].str.replace(fr, en, regex=False)

    # Construire datetime
    df["datetime"] = pd.to_datetime(
        df["date_en"] + f" {year} " + df["heure"],
        format="%A %d %B %Y %H:%M",
        errors="coerce"
    )

    # Trier + index
    df = df.sort_values("datetime").set_index("datetime")

    # Colonnes finales (propres pour le dashboard)
    # On garde l'essentiel + wave_mean utile
    df["wave_mean"] = (df["vague_min"] + df["vague_max"]) / 2

    df_final = df[
        ["vague_min", "vague_max", "wave_mean", "vent_vitesse_kmh", "vent_direction", "date", "heure"]
    ].copy()

    # Sauvegarde CSV à l'endroit voulu
    df_final.to_csv(save_path, index=True)

    return df_final
